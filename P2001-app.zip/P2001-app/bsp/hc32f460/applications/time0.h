#ifndef _TIME0_H_
#define	_TIME0_H_


extern void TIMER0_vInit(void);

#endif // !TIME0_H_
